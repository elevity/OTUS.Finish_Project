#!/bin/bash

###NGINX CONFIGS###
cp /root/app/CONFIGS/NGINX/nginx.conf /etc/nginx/
cp /root/app/CONFIGS/NGINX/defalt.conf /etc/nginx/conf.d
cp /root/app/CONFIGS/APACHE/httpd.conf /etc/httpd/conf/
cp /root/app/CONFIGS/APACHE/index.html /var/www/html/
cp /root/app/CONFIGS/APACHE/vh?.conf /etc/httpd/conf.d/
cp /root/app/CONFIGS/APACHE/vh1.conf /etc/httpd/conf.d/html1
cp /root/app/CONFIGS/APACHE/vh2.conf /etc/httpd/conf.d/html2
cp /root/app/CONFIGS/APACHE/vh3.conf /etc/httpd/conf.d/html3

systemctl start nginx
systemctl start httpd

