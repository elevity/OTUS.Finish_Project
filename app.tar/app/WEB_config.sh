#!/bin/bash

###NGINX CONFIGS###
cp /root/app/CONFIGS/NGINX/nginx.conf /etc/nginx/
cp /root/app/CONFIGS/NGINX/default.conf /etc/nginx/conf.d
cp /root/app/CONFIGS/APACHE/httpd.conf /etc/httpd/conf/
cp /root/app/CONFIGS/APACHE/index.html /var/www/html/
cp /root/app/CONFIGS/APACHE/vh?.conf /etc/httpd/conf.d/
cp -r /root/app/CONFIGS/APACHE/html?/ /var/www/

systemctl enable --now nginx
systemctl enable --now httpd

