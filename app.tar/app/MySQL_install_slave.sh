i#!/bin/bash

###PRE-INSTALL###

##SELinux##
setenforce 0
sed -i 's/^SELINUX=.*/SELINUX=disabled/g' /etc/selinux/config

##FIREWALL##
#systemctl stop firewalld
#systemctl disable firewalld
firewall-cmd --permanent --add-port={80,3306}/tcp
firewall-cmd --reload

##MySQL##
wget https://dev.mysql.com/get/mysql80-community-release-el7-5.noarch.rpm
md5sum mysql80-community-release-el7-5.noarch.rpm
rpm -ivh mysql80-community-release-el7-5.noarch.rpm
yum -y install mysql-server

##ENABLE&START##
systemctl enable --now mysqld
#grep "A temporary password" /var/log/mysqld.log
#mysql_secure_installation
#mysql -uroot -p

##CONFIGURE##
echo "server_id = 2" >> /etc/my.cnf
systemctl restart mysqld

