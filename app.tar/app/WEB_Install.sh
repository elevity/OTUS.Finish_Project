#!/bin/bash

###PRE-INSTALL###

##SELinux##
setenforce 0
sed -i 's/^SELINUX=.*/SELINUX=disabled/g' /etc/selinux/config

##FIREWALL##
#systemctl stop firewalld
#systemctl disable firewalld
firewall-cmd --permanent --add-port={80,8080,8081,8082,8083,3306,5044,5601}/tcp
firewall-cmd --reload
#80 - NGINX
#5044 — Logstash
#5601 — Kibana

###INSTALL###
##NGINX&APACHE##
yum install -y epel-release
yum install -y nginx
yum install -y httpd

