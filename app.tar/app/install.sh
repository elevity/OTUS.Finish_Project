#!/bin/bash

###PRE-INSTALL###

##SELinux##
setenforce 0
sed -i 's/^SELINUX=.*/SELINUX=disabled/g' /etc/selinux/config

##FIREWALL##
#systemctl stop firewalld
#systemctl disable firewalld
firewall-cmd --permanent --add-port={80,8080,8081,8082,8083,3306,9090,9093,9094,9100,5044,5601}/tcp
firewall-cmd --reload
#80 - NGINX
#8080,8081,8082,8083 - APACHE
#3306 - MySQL
#9090 - Prometheus
#9093,9094 - Alertmanager
#9100 - node_exporter
#5044 — Logstash
#5601 — Kibana

###INSTALL###
##NGINX&APACHE##
yum install -y epel-release
yum install -y wget
yum install -y nginx
yum install -y httpd

##MySQL##
#rpm -Uvh https://repo.mysql.com/mysql80-community-release-el7-3.noarch.rpm
#sed -i 's/enabled=1/enabled=0/' /etc/yum.repos.d/mysql-community.repo
#yum -y  --enablerepo=mysql80-community install mysql-community-server
wget https://dev.mysql.com/get/mysql80-community-release-el7-5.noarch.rpm
md5sum mysql80-community-release-el7-5.noarch.rpm
rpm -ivh mysql80-community-release-el7-5.noarch.rpm
yum -y install mysql-server

##PROMETHEUS##
yum install chrony
systemctl enable --now chronyd
yum install wget
wget https://github.com/prometheus/prometheus/releases/download/v2.20.1/prometheus-2.20.1.linux-amd64.tar.gz
wget https://github.com/prometheus/node_exporter/releases/download/v1.0.1/node_exporter-1.0.1.linux-amd64.tar.gz
wget https://dl.grafana.com/oss/release/grafana-8.4.3-1.x86_64.rpm
yum install grafana-8.4.3-1.x86_64.rpm



