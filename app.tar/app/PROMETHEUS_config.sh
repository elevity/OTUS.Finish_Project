#!/bin/bash

firewall-cmd --permanent --add-port={80,8080,8081,8082,8083,3306,9090,9093,9094,9100,3000,5044,5601}/tcp
firewall-cmd --reload

yum install chrony
systemctl enable --now chronyd
yum install wget
wget https://github.com/prometheus/prometheus/releases/download/v2.20.1/prometheus-2.20.1.linux-amd64.tar.gz
wget https://github.com/prometheus/node_exporter/releases/download/v1.0.1/node_exporter-1.0.1.linux-amd64.tar.gz
wget https://dl.grafana.com/oss/release/grafana-8.4.3-1.x86_64.rpm
yum install grafana-8.4.3-1.x86_64.rpm

###PROMETHEUS###
mkdir /etc/prometheus
mkdir /var/lib/prometheus
tar zxvf /root/app/prometheus-*.linux-amd64.tar.gz

cp /root/app/prometheus-*.linux-amd64/{prometheus,promtool} /usr/local/bin/
cp -r /root/app/prometheus-*.linux-amd64/console_libraries/ /etc/prometheus/
cp -r /root/app/prometheus-*.linux-amd64/consoles /etc/prometheus/
cp /root/app/CONFIGS/PROMETHEUS/prometheus.yml /etc/prometheus/

useradd --no-create-home --shell /bin/false prometheus
chown -R prometheus:prometheus /etc/prometheus /var/lib/prometheus
chown prometheus:prometheus /usr/local/bin/{prometheus,promtool}
cp /root/app/CONFIGS/PROMETHEUS/prometheus.service /etc/systemd/system/
systemctl daemon-reload
chown -R prometheus:prometheus /var/lib/prometheus
systemctl enable --now prometheus
###NODE_EXPORTER###
tar zxvf /root/app/node_exporter-*.linux-amd64.tar.gz
cp /root/app/node_exporter-*.linux-amd64/node_exporter /usr/local/bin/
useradd --no-create-home --shell /bin/false nodeusr
chown -R nodeusr:nodeusr /usr/local/bin/node_exporter
cp /root/app/CONFIGS/PROMETHEUS/node_exporter.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now node_exporter
systemctl restart prometheus
###GRAFANA###
systemctl daemon-reload
systemctl enable --now grafana-server

